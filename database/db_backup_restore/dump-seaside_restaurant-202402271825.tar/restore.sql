--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE seaside_restaurant;
--
-- Name: seaside_restaurant; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE seaside_restaurant WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE seaside_restaurant OWNER TO postgres;

\connect seaside_restaurant

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: composite_menu_ingredients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.composite_menu_ingredients (
    ingredients_id integer NOT NULL,
    menu_item_id integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.composite_menu_ingredients OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    customer_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    phone character varying(20) NOT NULL,
    email character varying(50)
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_customer_id_seq OWNER TO postgres;

--
-- Name: customer_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_customer_id_seq OWNED BY public.customer.customer_id;


--
-- Name: customer_preference; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.customer_preference AS
SELECT
    NULL::text AS customer_name,
    NULL::character varying(50) AS menu_name,
    NULL::bigint AS total_orders_made;


ALTER TABLE public.customer_preference OWNER TO postgres;

--
-- Name: delivery_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delivery_address (
    delivery_address_id integer NOT NULL,
    customer_id integer NOT NULL,
    address_type character varying(50) NOT NULL,
    city character varying(50) NOT NULL,
    province character varying(50) NOT NULL,
    street character varying(50) NOT NULL,
    postal_code character varying(20) NOT NULL
);


ALTER TABLE public.delivery_address OWNER TO postgres;

--
-- Name: delivery_address_delivery_address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.delivery_address_delivery_address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.delivery_address_delivery_address_id_seq OWNER TO postgres;

--
-- Name: delivery_address_delivery_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.delivery_address_delivery_address_id_seq OWNED BY public.delivery_address.delivery_address_id;


--
-- Name: delivery_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delivery_details (
    delivery_id integer NOT NULL,
    delivery_address_id integer NOT NULL,
    order_id integer NOT NULL,
    customer_id integer NOT NULL,
    delivery_status character varying(50) NOT NULL,
    delivery_date timestamp without time zone NOT NULL
);


ALTER TABLE public.delivery_details OWNER TO postgres;

--
-- Name: delivery_details_delivery_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.delivery_details_delivery_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.delivery_details_delivery_id_seq OWNER TO postgres;

--
-- Name: delivery_details_delivery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.delivery_details_delivery_id_seq OWNED BY public.delivery_details.delivery_id;


--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    employee_id integer NOT NULL,
    manager_id integer,
    address_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    role character varying(50) NOT NULL,
    hire_date timestamp without time zone NOT NULL,
    salary numeric(10,2),
    employment_status character varying(20) NOT NULL,
    termination_date date,
    termination_reason character varying(255),
    street character varying(50) NOT NULL,
    city character varying(50) NOT NULL,
    province character varying(50) NOT NULL,
    postal_code character varying(20) NOT NULL,
    CONSTRAINT salary_check CHECK ((salary > (0)::numeric))
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: employee_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_employee_id_seq OWNER TO postgres;

--
-- Name: employee_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_employee_id_seq OWNED BY public.employee.employee_id;


--
-- Name: ingredients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ingredients (
    ingredients_id integer NOT NULL,
    name character varying(50) NOT NULL,
    total_quantity integer NOT NULL,
    available_quantity integer NOT NULL,
    unit character varying(20) NOT NULL,
    cost_per_unit numeric(10,2) NOT NULL,
    availability boolean NOT NULL
);


ALTER TABLE public.ingredients OWNER TO postgres;

--
-- Name: ingredients_ingredients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ingredients_ingredients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ingredients_ingredients_id_seq OWNER TO postgres;

--
-- Name: ingredients_ingredients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ingredients_ingredients_id_seq OWNED BY public.ingredients.ingredients_id;


--
-- Name: menu_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_category (
    category_id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(255) NOT NULL
);


ALTER TABLE public.menu_category OWNER TO postgres;

--
-- Name: menu_category_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_category_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_category_category_id_seq OWNER TO postgres;

--
-- Name: menu_category_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_category_category_id_seq OWNED BY public.menu_category.category_id;


--
-- Name: menu_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_item (
    menu_item_id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(255) NOT NULL,
    price numeric(10,2) NOT NULL,
    availability boolean NOT NULL,
    promo_code character(6),
    category_id integer NOT NULL,
    CONSTRAINT chk_price_positive CHECK ((price > (0)::numeric))
);


ALTER TABLE public.menu_item OWNER TO postgres;

--
-- Name: menu_item_menu_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_item_menu_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_item_menu_item_id_seq OWNER TO postgres;

--
-- Name: menu_item_menu_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_item_menu_item_id_seq OWNED BY public.menu_item.menu_item_id;


--
-- Name: order_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_item (
    order_item integer NOT NULL,
    order_id integer NOT NULL,
    menu_item_id integer NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    menu_details character varying(255),
    CONSTRAINT chk_price_positive CHECK ((unit_price > (0)::numeric)),
    CONSTRAINT chk_qty_positive CHECK ((quantity > 0))
);


ALTER TABLE public.order_item OWNER TO postgres;

--
-- Name: order_item_order_item_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_item_order_item_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_item_order_item_seq OWNER TO postgres;

--
-- Name: order_item_order_item_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_item_order_item_seq OWNED BY public.order_item.order_item;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    order_id integer NOT NULL,
    customer_id integer NOT NULL,
    order_date timestamp without time zone NOT NULL,
    description character varying(255) NOT NULL,
    order_status character varying(50) NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    CONSTRAINT chk_price_positive CHECK ((total_amount > (0)::numeric))
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: order_summary_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.order_summary_view AS
 SELECT to_char(orders.order_date, 'YYYY'::text) AS year,
    to_char(orders.order_date, 'Month'::text) AS month,
    count(orders.order_id) AS total_orders,
    sum(orders.total_amount) AS total_revenue,
    count(DISTINCT orders.customer_id) AS total_customers
   FROM public.orders
  GROUP BY (to_char(orders.order_date, 'YYYY'::text)), (to_char(orders.order_date, 'Month'::text))
  ORDER BY (sum(orders.total_amount));


ALTER TABLE public.order_summary_view OWNER TO postgres;

--
-- Name: orders_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_order_id_seq OWNER TO postgres;

--
-- Name: orders_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_order_id_seq OWNED BY public.orders.order_id;


--
-- Name: payment_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_details (
    payment_id integer NOT NULL,
    customer_id integer NOT NULL,
    order_id integer NOT NULL,
    total_amount numeric(10,2),
    payment_method character varying(50),
    payment_date timestamp without time zone NOT NULL,
    payment_status character varying(50)
);


ALTER TABLE public.payment_details OWNER TO postgres;

--
-- Name: payment_details_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_details_payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_details_payment_id_seq OWNER TO postgres;

--
-- Name: payment_details_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payment_details_payment_id_seq OWNED BY public.payment_details.payment_id;


--
-- Name: promotion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promotion (
    promo_code character(6) NOT NULL,
    discount numeric(5,2) NOT NULL,
    begin_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    CONSTRAINT check_discount_range CHECK (((discount >= (0)::numeric) AND (discount <= (100)::numeric)))
);


ALTER TABLE public.promotion OWNER TO postgres;

--
-- Name: purchases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchases (
    purchase_id integer NOT NULL,
    order_id integer NOT NULL,
    customer_id integer NOT NULL,
    payment_date timestamp without time zone NOT NULL,
    quantity_purchased integer NOT NULL,
    total_order_amount numeric(10,2) NOT NULL,
    discount_applied numeric(10,2),
    discount_price numeric(10,2),
    total_hst numeric(10,2) NOT NULL,
    payment_amount numeric(10,2) NOT NULL
);


ALTER TABLE public.purchases OWNER TO postgres;

--
-- Name: purchases_purchase_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.purchases_purchase_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchases_purchase_id_seq OWNER TO postgres;

--
-- Name: purchases_purchase_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.purchases_purchase_id_seq OWNED BY public.purchases.purchase_id;


--
-- Name: shopping_cart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shopping_cart (
    cart_id integer NOT NULL,
    customer_id integer NOT NULL
);


ALTER TABLE public.shopping_cart OWNER TO postgres;

--
-- Name: shopping_cart_cart_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shopping_cart_cart_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shopping_cart_cart_id_seq OWNER TO postgres;

--
-- Name: shopping_cart_cart_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shopping_cart_cart_id_seq OWNED BY public.shopping_cart.cart_id;


--
-- Name: shopping_cart_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shopping_cart_items (
    cart_item_id integer NOT NULL,
    cart_id integer NOT NULL,
    menu_item_id integer NOT NULL,
    price numeric(10,2) NOT NULL,
    CONSTRAINT chk_price_positive CHECK ((price > (0)::numeric))
);


ALTER TABLE public.shopping_cart_items OWNER TO postgres;

--
-- Name: shopping_cart_items_cart_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shopping_cart_items_cart_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shopping_cart_items_cart_item_id_seq OWNER TO postgres;

--
-- Name: shopping_cart_items_cart_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shopping_cart_items_cart_item_id_seq OWNED BY public.shopping_cart_items.cart_item_id;


--
-- Name: top_menu_items_per_category; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.top_menu_items_per_category AS
 WITH best_selling_menu AS (
         SELECT mc.name AS menu_category,
            mi.name AS menu_item,
            count(*) AS total_orders_made
           FROM ((public.menu_item mi
             JOIN public.menu_category mc ON ((mi.category_id = mc.category_id)))
             JOIN public.order_item oi ON ((mi.menu_item_id = oi.menu_item_id)))
          GROUP BY mc.name, mi.name
          ORDER BY mc.name, (count(*)) DESC
        ), ranked_orders AS (
         SELECT best_selling_menu.menu_category,
            best_selling_menu.menu_item,
            best_selling_menu.total_orders_made,
            rank() OVER (PARTITION BY best_selling_menu.menu_category ORDER BY best_selling_menu.total_orders_made DESC) AS order_rankings
           FROM best_selling_menu
        )
 SELECT ranked_orders.menu_category,
    ranked_orders.menu_item,
    ranked_orders.total_orders_made,
        CASE
            WHEN (ranked_orders.order_rankings = 1) THEN 'Top Selling Menu'::text
            ELSE NULL::text
        END AS order_status
   FROM ranked_orders
  WHERE (ranked_orders.order_rankings = 1);


ALTER TABLE public.top_menu_items_per_category OWNER TO postgres;

--
-- Name: top_sold_menu_categories; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.top_sold_menu_categories AS
 WITH best_selling_menu AS (
         SELECT mc.name AS category_name,
            count(*) AS total_orders,
            dense_rank() OVER (ORDER BY (count(*)) DESC) AS category_rank
           FROM ((public.menu_item mi
             JOIN public.menu_category mc USING (category_id))
             JOIN public.order_item oi USING (menu_item_id))
          GROUP BY mc.name
        )
 SELECT best_selling_menu.category_name,
    best_selling_menu.total_orders,
        CASE
            WHEN (best_selling_menu.category_rank = 1) THEN 'Top Ordered Menu Category'::text
            WHEN (best_selling_menu.category_rank = 2) THEN 'Second Ordered Menu Category'::text
            ELSE NULL::text
        END AS sales_status
   FROM best_selling_menu
  WHERE (best_selling_menu.category_rank <= 2);


ALTER TABLE public.top_sold_menu_categories OWNER TO postgres;

--
-- Name: customer customer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN customer_id SET DEFAULT nextval('public.customer_customer_id_seq'::regclass);


--
-- Name: delivery_address delivery_address_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_address ALTER COLUMN delivery_address_id SET DEFAULT nextval('public.delivery_address_delivery_address_id_seq'::regclass);


--
-- Name: delivery_details delivery_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_details ALTER COLUMN delivery_id SET DEFAULT nextval('public.delivery_details_delivery_id_seq'::regclass);


--
-- Name: employee employee_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee ALTER COLUMN employee_id SET DEFAULT nextval('public.employee_employee_id_seq'::regclass);


--
-- Name: ingredients ingredients_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredients ALTER COLUMN ingredients_id SET DEFAULT nextval('public.ingredients_ingredients_id_seq'::regclass);


--
-- Name: menu_category category_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_category ALTER COLUMN category_id SET DEFAULT nextval('public.menu_category_category_id_seq'::regclass);


--
-- Name: menu_item menu_item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item ALTER COLUMN menu_item_id SET DEFAULT nextval('public.menu_item_menu_item_id_seq'::regclass);


--
-- Name: order_item order_item; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item ALTER COLUMN order_item SET DEFAULT nextval('public.order_item_order_item_seq'::regclass);


--
-- Name: orders order_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN order_id SET DEFAULT nextval('public.orders_order_id_seq'::regclass);


--
-- Name: payment_details payment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_details ALTER COLUMN payment_id SET DEFAULT nextval('public.payment_details_payment_id_seq'::regclass);


--
-- Name: purchases purchase_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchases ALTER COLUMN purchase_id SET DEFAULT nextval('public.purchases_purchase_id_seq'::regclass);


--
-- Name: shopping_cart cart_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shopping_cart ALTER COLUMN cart_id SET DEFAULT nextval('public.shopping_cart_cart_id_seq'::regclass);


--
-- Name: shopping_cart_items cart_item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shopping_cart_items ALTER COLUMN cart_item_id SET DEFAULT nextval('public.shopping_cart_items_cart_item_id_seq'::regclass);


--
-- Data for Name: composite_menu_ingredients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.composite_menu_ingredients (ingredients_id, menu_item_id, quantity) FROM stdin;
\.
COPY public.composite_menu_ingredients (ingredients_id, menu_item_id, quantity) FROM '$$PATH$$/3737.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (customer_id, first_name, last_name, phone, email) FROM stdin;
\.
COPY public.customer (customer_id, first_name, last_name, phone, email) FROM '$$PATH$$/3739.dat';

--
-- Data for Name: delivery_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.delivery_address (delivery_address_id, customer_id, address_type, city, province, street, postal_code) FROM stdin;
\.
COPY public.delivery_address (delivery_address_id, customer_id, address_type, city, province, street, postal_code) FROM '$$PATH$$/3745.dat';

--
-- Data for Name: delivery_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.delivery_details (delivery_id, delivery_address_id, order_id, customer_id, delivery_status, delivery_date) FROM stdin;
\.
COPY public.delivery_details (delivery_id, delivery_address_id, order_id, customer_id, delivery_status, delivery_date) FROM '$$PATH$$/3749.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (employee_id, manager_id, address_id, first_name, last_name, role, hire_date, salary, employment_status, termination_date, termination_reason, street, city, province, postal_code) FROM stdin;
\.
COPY public.employee (employee_id, manager_id, address_id, first_name, last_name, role, hire_date, salary, employment_status, termination_date, termination_reason, street, city, province, postal_code) FROM '$$PATH$$/3729.dat';

--
-- Data for Name: ingredients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ingredients (ingredients_id, name, total_quantity, available_quantity, unit, cost_per_unit, availability) FROM stdin;
\.
COPY public.ingredients (ingredients_id, name, total_quantity, available_quantity, unit, cost_per_unit, availability) FROM '$$PATH$$/3731.dat';

--
-- Data for Name: menu_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_category (category_id, name, description) FROM stdin;
\.
COPY public.menu_category (category_id, name, description) FROM '$$PATH$$/3733.dat';

--
-- Data for Name: menu_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_item (menu_item_id, name, description, price, availability, promo_code, category_id) FROM stdin;
\.
COPY public.menu_item (menu_item_id, name, description, price, availability, promo_code, category_id) FROM '$$PATH$$/3736.dat';

--
-- Data for Name: order_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_item (order_item, order_id, menu_item_id, quantity, unit_price, menu_details) FROM stdin;
\.
COPY public.order_item (order_item, order_id, menu_item_id, quantity, unit_price, menu_details) FROM '$$PATH$$/3751.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (order_id, customer_id, order_date, description, order_status, total_amount) FROM stdin;
\.
COPY public.orders (order_id, customer_id, order_date, description, order_status, total_amount) FROM '$$PATH$$/3747.dat';

--
-- Data for Name: payment_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_details (payment_id, customer_id, order_id, total_amount, payment_method, payment_date, payment_status) FROM stdin;
\.
COPY public.payment_details (payment_id, customer_id, order_id, total_amount, payment_method, payment_date, payment_status) FROM '$$PATH$$/3755.dat';

--
-- Data for Name: promotion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.promotion (promo_code, discount, begin_date, end_date) FROM stdin;
\.
COPY public.promotion (promo_code, discount, begin_date, end_date) FROM '$$PATH$$/3734.dat';

--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchases (purchase_id, order_id, customer_id, payment_date, quantity_purchased, total_order_amount, discount_applied, discount_price, total_hst, payment_amount) FROM stdin;
\.
COPY public.purchases (purchase_id, order_id, customer_id, payment_date, quantity_purchased, total_order_amount, discount_applied, discount_price, total_hst, payment_amount) FROM '$$PATH$$/3753.dat';

--
-- Data for Name: shopping_cart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shopping_cart (cart_id, customer_id) FROM stdin;
\.
COPY public.shopping_cart (cart_id, customer_id) FROM '$$PATH$$/3741.dat';

--
-- Data for Name: shopping_cart_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shopping_cart_items (cart_item_id, cart_id, menu_item_id, price) FROM stdin;
\.
COPY public.shopping_cart_items (cart_item_id, cart_id, menu_item_id, price) FROM '$$PATH$$/3743.dat';

--
-- Name: customer_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_customer_id_seq', 200, true);


--
-- Name: delivery_address_delivery_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.delivery_address_delivery_address_id_seq', 200, true);


--
-- Name: delivery_details_delivery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.delivery_details_delivery_id_seq', 1, false);


--
-- Name: employee_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_employee_id_seq', 20, true);


--
-- Name: ingredients_ingredients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ingredients_ingredients_id_seq', 40, true);


--
-- Name: menu_category_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_category_category_id_seq', 5, true);


--
-- Name: menu_item_menu_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_item_menu_item_id_seq', 25, true);


--
-- Name: order_item_order_item_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_item_order_item_seq', 2559, true);


--
-- Name: orders_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_order_id_seq', 157, true);


--
-- Name: payment_details_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_details_payment_id_seq', 54, true);


--
-- Name: purchases_purchase_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.purchases_purchase_id_seq', 54, true);


--
-- Name: shopping_cart_cart_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shopping_cart_cart_id_seq', 205, true);


--
-- Name: shopping_cart_items_cart_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shopping_cart_items_cart_item_id_seq', 400, true);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customer_id);


--
-- Name: delivery_address delivery_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_address
    ADD CONSTRAINT delivery_address_pkey PRIMARY KEY (delivery_address_id);


--
-- Name: delivery_details delivery_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_details
    ADD CONSTRAINT delivery_details_pkey PRIMARY KEY (delivery_id);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (employee_id);


--
-- Name: ingredients ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredients
    ADD CONSTRAINT ingredients_pkey PRIMARY KEY (ingredients_id);


--
-- Name: menu_category menu_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_category
    ADD CONSTRAINT menu_category_pkey PRIMARY KEY (category_id);


--
-- Name: menu_item menu_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_pkey PRIMARY KEY (menu_item_id);


--
-- Name: order_item order_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item
    ADD CONSTRAINT order_item_pkey PRIMARY KEY (order_item);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (order_id);


--
-- Name: payment_details payment_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_details
    ADD CONSTRAINT payment_details_pkey PRIMARY KEY (payment_id);


--
-- Name: composite_menu_ingredients pkey_menu_ingredients; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.composite_menu_ingredients
    ADD CONSTRAINT pkey_menu_ingredients PRIMARY KEY (ingredients_id, menu_item_id);


--
-- Name: promotion promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion
    ADD CONSTRAINT promotion_pkey PRIMARY KEY (promo_code);


--
-- Name: purchases purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (purchase_id);


--
-- Name: shopping_cart_items shopping_cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shopping_cart_items
    ADD CONSTRAINT shopping_cart_items_pkey PRIMARY KEY (cart_item_id);


--
-- Name: shopping_cart shopping_cart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shopping_cart
    ADD CONSTRAINT shopping_cart_pkey PRIMARY KEY (cart_id);


--
-- Name: ingredients unique_ingredient_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredients
    ADD CONSTRAINT unique_ingredient_name UNIQUE (name);


--
-- Name: customer_preference _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.customer_preference AS
 SELECT (((c.first_name)::text || ' '::text) || (c.last_name)::text) AS customer_name,
    m.name AS menu_name,
    count(*) AS total_orders_made
   FROM (((public.orders o
     JOIN public.customer c USING (customer_id))
     JOIN public.order_item oi USING (order_id))
     JOIN public.menu_item m USING (menu_item_id))
  GROUP BY (((c.first_name)::text || ' '::text) || (c.last_name)::text), m.menu_item_id
  ORDER BY (count(*)) DESC;


--
-- Name: shopping_cart_items fk_cart_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shopping_cart_items
    ADD CONSTRAINT fk_cart_id FOREIGN KEY (cart_id) REFERENCES public.shopping_cart(cart_id);


--
-- Name: shopping_cart fk_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shopping_cart
    ADD CONSTRAINT fk_customer_id FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: shopping_cart_items fk_menu_item; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shopping_cart_items
    ADD CONSTRAINT fk_menu_item FOREIGN KEY (menu_item_id) REFERENCES public.menu_item(menu_item_id);


--
-- Name: menu_item fkey_category; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT fkey_category FOREIGN KEY (category_id) REFERENCES public.menu_category(category_id);


--
-- Name: delivery_address fkey_customer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_address
    ADD CONSTRAINT fkey_customer FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: delivery_details fkey_customer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_details
    ADD CONSTRAINT fkey_customer FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: purchases fkey_customer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT fkey_customer FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: payment_details fkey_customer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_details
    ADD CONSTRAINT fkey_customer FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: orders fkey_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fkey_customer_id FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: delivery_details fkey_delivery_address; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_details
    ADD CONSTRAINT fkey_delivery_address FOREIGN KEY (delivery_address_id) REFERENCES public.delivery_address(delivery_address_id);


--
-- Name: employee fkey_employee_manager; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT fkey_employee_manager FOREIGN KEY (manager_id) REFERENCES public.employee(employee_id);


--
-- Name: composite_menu_ingredients fkey_ingredients; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.composite_menu_ingredients
    ADD CONSTRAINT fkey_ingredients FOREIGN KEY (ingredients_id) REFERENCES public.ingredients(ingredients_id);


--
-- Name: composite_menu_ingredients fkey_menu_item; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.composite_menu_ingredients
    ADD CONSTRAINT fkey_menu_item FOREIGN KEY (menu_item_id) REFERENCES public.menu_item(menu_item_id);


--
-- Name: order_item fkey_menu_item; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item
    ADD CONSTRAINT fkey_menu_item FOREIGN KEY (menu_item_id) REFERENCES public.menu_item(menu_item_id);


--
-- Name: delivery_details fkey_order; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_details
    ADD CONSTRAINT fkey_order FOREIGN KEY (order_id) REFERENCES public.orders(order_id);


--
-- Name: order_item fkey_order; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item
    ADD CONSTRAINT fkey_order FOREIGN KEY (order_id) REFERENCES public.orders(order_id);


--
-- Name: purchases fkey_orders; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT fkey_orders FOREIGN KEY (order_id) REFERENCES public.orders(order_id);


--
-- Name: payment_details fkey_orders; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_details
    ADD CONSTRAINT fkey_orders FOREIGN KEY (order_id) REFERENCES public.orders(order_id);


--
-- Name: menu_item fkey_promotion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT fkey_promotion FOREIGN KEY (promo_code) REFERENCES public.promotion(promo_code);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

